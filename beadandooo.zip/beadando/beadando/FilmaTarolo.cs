﻿using System;
using System.Collections.Generic;
using System.Text;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Beadando
{
    class FilmTarolo
    {
        // Lazyvel csak akkor hozom létre a listát, amikor először szükségem van rá
        private Lazy<List<Film>> filmek;

        public List<Film> Filmek
        {
            get { return filmek.Value; }
        }

        public FilmTarolo()
        {
            filmek = new Lazy<List<Film>>(() => new List<Film>());
        }


        public void Feltoltes()
        {
            Filmek.Add(new Film("Inception", "Christopher Nolan", 2010, 9.1));
            Filmek.Add(new Film("Interstellar", "Christopher Nolan", 2014, 9.3));
            Filmek.Add(new Film("Titanic", "James Cameron", 1997, 8.4));
            Filmek.Add(new Film("Avatar", "James Cameron", 2009, 8.0));
            Filmek.Add(new Film("Gladiator", "Ridley Scott", 2000, 8.8));
            Filmek.Add(new Film("Alien", "Ridley Scott", 1979, 8.5));
            Filmek.Add(new Film("Joker", "Todd Phillips", 2019, 8.7));
            Filmek.Add(new Film("Batman Begins", "Christopher Nolan", 2005, 8.3));
            Filmek.Add(new Film("The Dark Knight", "Christopher Nolan", 2008, 9.4));
            Filmek.Add(new Film("The Prestige", "Christopher Nolan", 2006, 8.9));
            Filmek.Add(new Film("Dune", "Denis Villeneuve", 2021, 8.6));
            Filmek.Add(new Film("Blade Runner 2049", "Denis Villeneuve", 2017, 8.7));
            Filmek.Add(new Film("The Matrix", "Wachowski", 1999, 9.0));
            Filmek.Add(new Film("John Wick", "Chad Stahelski", 2014, 8.1));
            Filmek.Add(new Film("Fight Club", "David Fincher", 1999, 9.2));
            Filmek.Add(new Film("Se7en", "David Fincher", 1995, 8.9));
            Filmek.Add(new Film("Shutter Island", "Martin Scorsese", 2010, 8.8));
            Filmek.Add(new Film("The Wolf of Wall Street", "Martin Scorsese", 2013, 8.5));
            Filmek.Add(new Film("Whiplash", "Damien Chazelle", 2014, 8.9));
            Filmek.Add(new Film("La La Land", "Damien Chazelle", 2016, 8.2));
        }

        public void UjFilm(Film film)
        {
            Filmek.Add(film);
        }

        // Ezzel törlök egy filmet a listából
        public void FilmTorles(string cim)
        {
            Film torlendo = Filmek.Find(f => f.Cim == cim);

            if (torlendo != null)
            {
                Filmek.Remove(torlendo);
            }
        }

        // Ezzel a metódussal keresek egy filmet cím alapján
        public Film FilmKereses(string cim)
        {
            return Filmek.Find(f => f.Cim == cim);
        }

        // itt  rendezem a filmeket év szerint
        public void Rendezes()
        {
            Filmek.Sort((a, b) => a.Ev.CompareTo(b.Ev));
        }

        // Ezzel a metódussal írom ki a filmek számát
        public void FilmDarab()
        {
            Console.WriteLine($"Filmek száma: {Filmek.Count}");
        }

        // szerepel-e egy film a listában
        public void TartalmazE(string cim)
        {
            bool van = Filmek.Any(f => f.Cim == cim);

            if (van)
            {
                Console.WriteLine("A film megtalálható.");
            }
            else
            {
                Console.WriteLine("A film nincs a listában.");
            }
        }

        public void Listazas()
        {
            foreach (Film film in Filmek)
            {
                Console.WriteLine(film);
            }
        }

        // ICloneable használata
        public void KlonozoPeldany()
        {
            Film eredeti = Filmek[0];

            // Itt készítek másolatot az objektumról
            Film masolat = (Film)eredeti.Clone();

            // A másolat adatait módosítom
            masolat.Cim = "Klónozott film";

            Console.WriteLine("Eredeti objektum:");
            Console.WriteLine(eredeti);

            Console.WriteLine();

            Console.WriteLine("Klónozott objektum:");
            Console.WriteLine(masolat);
        }
    }
}