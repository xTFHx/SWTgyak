﻿using System;
using static System.Net.WebRequestMethods;

namespace Beadando
{
    class Program
    {
        static void Main(string[] args)
        {
            FilmTarolo tarolo = new FilmTarolo();

            tarolo.Feltoltes();

            Console.WriteLine("===== FILMLISTA =====");
            tarolo.Listazas();

            Console.WriteLine();

            tarolo.FilmDarab();

            Console.WriteLine();

            Console.WriteLine("===== KERESÉS =====");

            // filmre keresés -------------------------
            Film talalat = tarolo.FilmKereses("Inception");

            if (talalat != null)
            {
                Console.WriteLine(talalat);
            }

            Console.WriteLine();

            Console.WriteLine("===== CONTAINS =====");

            // Itt ellenőrzöm, hogy benne van-e a listában.---------
            tarolo.TartalmazE("Avatar");

            Console.WriteLine();

            Console.WriteLine("===== RENDEZÉS =====");
            
            // -----------rendezés--------------------------------
            tarolo.Rendezes();
            tarolo.Listazas();

            Console.WriteLine();

            Console.WriteLine("===== ÚJ FILM =====");

            // Itt adok hozzá új filmet.--------------------------------------
            tarolo.UjFilm(new Film("Oppenheimer", "Christopher Nolan", 2023, 9.0));
            tarolo.Listazas();

            Console.WriteLine();

            Console.WriteLine("===== TÖRLÉS =====");

            // Itt törlök egy filmet. ----------------------------------------------
            tarolo.FilmTorles("Titanic");
            tarolo.Listazas();

            Console.WriteLine();

            Console.WriteLine("===== KLÓNOZÁS =====");

            // obj. klónozás -------------------------------------
            tarolo.KlonozoPeldany();

            Console.ReadKey();
        }
    }
}