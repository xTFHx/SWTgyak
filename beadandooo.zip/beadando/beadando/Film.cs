﻿using System;
using System.Collections.Generic;
using System.Text;
using System;

namespace Beadando
{
    class Film : ICloneable
    {
        public string Cim { get; set; }

        public string Rendezo { get; set; }

        public int Ev { get; set; }

        public double Ertekeles { get; set; }

        public Film(string cim, string rendezo, int ev, double ertekeles)
        {
            Cim = cim;
            Rendezo = rendezo;
            Ev = ev;
            Ertekeles = ertekeles;
        }

        // A Clone metódussal készítek egy új objektumpéldányt
        public object Clone()
        {
            return new Film(Cim, Rendezo, Ev, Ertekeles);
        }

        // A ToString metódust felülírom, hogy jól nézzen ki az adatkiírás
        public override string ToString()
        {
            return $"{Cim} - {Rendezo} - {Ev} - {Ertekeles}";
        }
    }
}